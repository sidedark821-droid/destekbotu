MAIN=dc.py
MEMORY=100
VERSION=recommended
DISPLAY_NAME=KrytexBot
DESCRIPTION=Destek Bilet Botu